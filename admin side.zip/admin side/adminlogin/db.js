// db.js
const { MongoClient } = require('mongodb');

const url = 'mongodb://localhost:27017/';
const dbName = 'test';

async function connect() {
  const client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true });
  await client.connect();
  console.log('Connected to MongoDB');
  const db = client.db(dbName);
  return db;
}

module.exports = connect;
