// server.js
const express = require('express');
const connect = require('./db');

const app = express();
const port = 5000;

// Set up EJS as the templating engine
app.set('view engine', 'ejs');

// Route to fetch and display data
app.get('/', async (req, res) => {
  try {
    const db = await connect();
    const collection = db.collection('uploads.files');
    const data = await collection.find({}).toArray();
    res.render('index', { data });
  } catch (err) {
    console.error(err);
    res.status(500).send('Internal Server Error');
  }
});








app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

// node server.js