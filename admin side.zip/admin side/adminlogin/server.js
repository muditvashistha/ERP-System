const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const connect = require('./db');
const Grid = require('gridfs-stream');
// Initialize the app
const app = express();
const port = 3000;



// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/AdminCred', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});


const mongoURI = 'mongodb://localhost:27017/test';
const conn = mongoose.createConnection(mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  });


let gfs;
conn.once('open', () => {
  // Init Stream
  gfs = Grid(conn.db, mongoose.mongo);
  gfs.collection('uploads.files'); // Use your GridFS collection name if it's different
});

// Define the schema and model
const adminSchema = new mongoose.Schema({
    email: String,
    password: String
    
}, { collection: 'AdminRec' });


const Admin = mongoose.model('Admin', adminSchema);

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Use body-parser middleware
app.use(bodyParser.urlencoded({ extended: true }));

// Serve the login form
app.get('/', (req, res) => {
    res.render('admin_login');
});



app.get('/files', async (req, res) => {
    // try {
    //   const files = await gfs.files.find().toArray();
  
    //   if (!files || files.length === 0) {
    //     return res.status(404).json({ msg: 'No files found' });
    //   }
  
      
    //   res.render('files', { files });
    // } catch (error) {
    //   res.status(500).json({ msg: 'Server Error', error });
    // }
    try {
      const db = await connect();
      const collection = db.collection('uploads.files');
      const data = await collection.find({}).toArray();
      res.render('files', { data });
    } catch (err) {
      console.error(err);
      res.status(500).send('Internal Server Error');
    }
  });



// Handle login form submission
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        // Find the admin by email and password
        const admin = await Admin.findOne({ email: email, password: password });

        if (admin) {
            console.log('Login successful');
            // res.send('Login successful');
            res.redirect('/files')
        } else {
            console.log('Invalid email or password');
            res.send('Invalid email or password');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});



// app.get('/index', (req, res) => {
//     res.render('index');
// });






app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
