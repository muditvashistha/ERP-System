// node server.js

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const session = require('express-session');
const mon= require('mongodb')

// copied variables from app.js from work folder
const crypto=require('crypto');
const multer=require('multer');
const {GridFsStorage} = require('multer-gridfs-storage');
const Grid=require('gridfs-stream');
const metthodOverride=require('method-override');
const fs = require('fs');



// Create express app
const app = express();
app.use(express.static("./public"));
// MongoDB connection string
const dbURI = 'mongodb://localhost:27017/UserCreds';

// Connect to MongoDB
mongoose.connect(dbURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected...'))
  .catch(err => console.log(err));



// Create a schema and model for User
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String
});

const User = mongoose.model('record', userSchema);

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// app.use(session({
//   secret: '268xceq5dwm2wexmpb6qgqfeqf1a2ud2', 
//   resave: false,
//   saveUninitialized: true,
//   cookie: { secure: false } 
// }));






// Set view engine to EJS
app.set('view engine', 'ejs');

// Routes
app.get('/', (req, res) => {
  res.render('login');
});
app.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  const newUser = new User({ name, email, password });
  await newUser.save();
//   res.redirect('/');
  res.redirect('/?success=true');
  
});

app.get('/index', (req, res) => {
  res.render('index');
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email, password });
  if (user) {
    loggedInUserName = user.name;
    address=user.email;
    console.log('Login successful');
    res.redirect('/index');  
  } else {
    console.log('Login failed');
    res.redirect('/');  // Redirect back to login page on failure
  }
});

// Start the server
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));



// file upload script integrated from the app.js file of work folder

// middleware
app.use(bodyParser.json())
app.use(metthodOverride('_method'))

// Mongodb URI
const mongoURI='mongodb://localhost:27017/';

// connection
const conn=mongoose.createConnection(mongoURI);

// gridfs stream variable
let gfs;

conn.once('open',function(){
    gfs=Grid(conn.db,mongoose.mongo);
    gfs.collection('uploads');
})

// storage engine
const storage = new GridFsStorage({
    url: mongoURI,
    file: (req, file) => {
      return new Promise((resolve, reject) => {
        crypto.randomBytes(16, (err, buf) => {
          if (err) {
            return reject(err);
          }
          const filename = buf.toString('hex') + path.extname(file.originalname);
          const fileInfo = {
            filename: file.originalname,
            bucketName: 'uploads',
            metadata:{username:loggedInUserName,email_address:address}
          };
          resolve(fileInfo);
        });
      });
    }
  });
  const upload = multer({ storage });

  
// @route GET /
// @desc loads form
app.set('view engine','ejs');
app.get('/',(req,res) => {
    res.render('index');
});

// @route POST /upload
// @desc  Uploads file to DB
app.post('/upload',upload.single('file'),(req,res) =>{
    // res.json({file:req.file})
    res.redirect('/index');
    console.log(file.filemname);
});



// @route GET /files
// @desc  Display all files in JSON

app.get('/files',(req,res) =>{
    gfs.files.find().toArray((err,files) =>{
        if(!files || files.length===0){
            return res.status(404).json({
                err:'no files exist'
            });
        }
    })

});

app.get('/userhist', async (req, res) => {
  

  

  try {
      const files = await gfs.files.find({ 'metadata.email_address': address }).toArray();
      res.render('userhist', { files });
  } catch (error) {
      console.error(error);
      res.status(500).send('An error occurred while fetching upload history.');
  }
});



// Download route
app.get('/download/:id', (req, res) => {
  const fileId = req.params.id;
  console.log(`Attempting to download file with ID: ${fileId}`);

  gfs.files.findOne({ _id: new mongoose.Types.ObjectId(fileId) }, (err, file) => {
    if (err) {
      console.error('Error finding file:', err);
      return res.status(500).json({ err: 'Error finding file' });
    }
    if (!file) {
      console.log('No file found');
      return res.status(404).json({ err: 'No file exists' });
    }

    console.log('File found:', file);

    // Create a read stream from GridFS
    const readstream = gfs.createReadStream({ _id: fileId });

    // Handle errors on the read stream
    readstream.on('error', (err) => {
      console.error('Error reading file:', err);
      res.status(500).json({ err: 'Error reading file' });
    });

    // Handle the end of the read stream
    readstream.on('end', () => {
      console.log('Read stream ended');
    });

    // Log when piping starts
    readstream.on('open', () => {
      console.log('Starting to pipe read stream to response');
    });

    // Log data chunks (for debugging purposes, can be removed later)
    readstream.on('data', (chunk) => {
      console.log('Received data chunk of size:', chunk.length);
    });

    // Set the headers to prompt for download
    res.setHeader('Content-Disposition', `attachment; filename="${file.filename}"`);
    res.setHeader('Content-Type', file.contentType);

    // Pipe the read stream to the response
    readstream.pipe(res);
  });
});





// const port=5000;

// app.listen(port, () => console.log(`Server started on port ${port}`));